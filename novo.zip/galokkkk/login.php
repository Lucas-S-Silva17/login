<?php
session_start();

// Define qual tela mostrar
$tela = isset($_GET['tela']) ? $_GET['tela'] : 'login';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema</title>

    <style>
        body {
            font-family: Arial;
            background: linear-gradient(135deg, #604ffe, #00f2fe);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        form{
            width: 100%;
        }
        input,button{
            width: 100%;
        }
        .box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            width: 340px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            text-align: center;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #4facfe;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #00c6ff;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
        }

        .msg {
            text-align: center;
            font-weight: bold;
        }

        .erro { color: red; }
        .sucesso { color: green; }
    </style>
</head>

<body>

<div class="box">

<?php
// ================= CADASTRO =================
if ($tela == "cadastro") {
?>

    <h2>Cadastro</h2>
    <form method="post">
        <input type="text" name="email" placeholder="E-mail" required>
        <input type="password" name="senha" placeholder="Senha" required>

        <button name="cadastrar">Cadastrar</button>
    </form>

    <a href="?tela=login">Já tem conta? Faça login</a>

<?php
} else {
// ================= LOGIN =================
?>

    <h2>Login</h2>
    <form method="post">
        <input type="text" name="email_login" placeholder="E-mail" required>
        <input type="password" name="senha_login" placeholder="Senha" required>

        <button name="logar">Entrar</button>
    </form>

    <a href="?tela=cadastro">Não tem uma conta? Cadastre-se</a>

<?php
}
?>

<?php
// ===== LÓGICA =====

// CADASTRAR
if (isset($_POST["cadastrar"])) {
    $_SESSION["email"] = $_POST["email"];
    $_SESSION["senha"] = $_POST["senha"];

    echo "<p class='msg sucesso'>Cadastro realizado! Redirecionando...</p>";

    // Redireciona para login
    header("refresh:2;url=?tela=login");
}

// LOGIN
if (isset($_POST["logar"])) {

    if (!isset($_SESSION["email"])) {
        echo "<p class='msg erro'>Cadastre-se primeiro!</p>";
    } else {
        if ($_POST["email_login"] == $_SESSION["email"] &&
            $_POST["senha_login"] == $_SESSION["senha"]) {

            echo "<p class='msg sucesso'>Login realizado com sucesso!</p>";
        } else {
            echo "<p class='msg erro'>E-mail ou senha incorretos</p>";
        }
    }
}
?>

</div>

</body>
</html>
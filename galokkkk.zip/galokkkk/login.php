<?php
if (isset($_POST["senha"]) && isset($_POST["email"])) {

    $usuario = ($_POST["senha"]);
    $email = ($_POST["email"]);

    echo "Cadastro concluido <br><br>";
    echo '
    <form method="post">
        E-mail:
        <input type="text" name="email1">
        Senha:
        <input type="text" name="senha2">

        <input type="submit" value="Entrar">

    </form>';
}
if (isset($_POST["senha2"]) && isset($_POST["email1"])) {

    $usuariologin = ($_POST["senha2"]);
    $emaillogin = ($_POST["email1"]);

    if($usuariologin == $usuario && $emaillogin == $email){

      echo  "Senha correta";
    }else{
        echo "senha incorreta, tente novamente";
    }


}
